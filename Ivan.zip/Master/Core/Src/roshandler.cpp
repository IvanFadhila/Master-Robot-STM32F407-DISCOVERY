/*
 * roshandler.cpp
 *
 *  Created on: Mar 23, 2021
 *      Author: Fattah .Alf
 */
#include <roshandler.h>
#include <ros.h>
#include <geometry_msgs/Quaternion.h>


volatile int direction[4] = {0,0,0,0};

void pwm_callback(const geometry_msgs::Quaternion& data){
	direction[0] = data.x;
	direction[1] = data.y;
	direction[2] = data.w;
	direction[3] = data.z;
}

ros::NodeHandle nh;

ros::Subscriber<geometry_msgs::Quaternion> pwm("mini_robot/pwm", &pwm_callback);

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){
  nh.getHardware()->flush();
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
  nh.getHardware()->reset_rbuf();
}

void setup(void)
{
  nh.initNode();
  nh.subscribe(pwm);
}

void loop(void)
{
  HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0);
  nh.spinOnce();
  HAL_Delay(10);
}

